<?php
include_once($_SERVER['DOCUMENT_ROOT'] . "/application/models/model_edit.php");

class Controller_Edit extends Controller
{

	function __construct()
	{
		$this->model = new Model_Edit();
		$this->view = new View();
	}

	function action_index()
	{

		if (!isset($_SESSION['loggedin'])) {
			header("Location: /login");
		}
		if (isset($_POST['logout'])) {
			session_start();
			session_destroy();

			header("Location: /login");
		}
		//Update data

		$result = $this->model->update_data();

		if ($result) {
			$this->view->generate('reg_view.php', 'template_view.php');
		}
		//Delete data
		$this->model->delete_data();


		$this->view->generate('edit_view.php', 'template_view.php');
	}
}
