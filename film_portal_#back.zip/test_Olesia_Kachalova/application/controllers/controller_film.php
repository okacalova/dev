<?php
include_once($_SERVER['DOCUMENT_ROOT'] . "/application/models/model_film.php");

class Controller_Film extends Controller
{


    function __construct()
    {
        $this->model = new Model_Film();
        $this->view = new View();
    }


    function action_index()
    {
        if (!isset($_SESSION['loggedin'])) {
            header("Location: /login");
        }
        if (isset($_POST['logout'])) {
            session_start();
            session_destroy();

            header("Location: /login");
        }


        //FindId

        $data = $this->model->findId();

        //Update data

        $result = $this->model->update_data();

        if ($result) {
            $this->view->generate('film_view.php', 'template_view.php');
        }
        //Delete data
        $this->model->delete_data();
        //Insert data
        $this->model->Insert_data();

        //Send data 
        if ($data) {
            $this->view->generate('film_view.php', 'template_view.php', ['data' => $data]);
        }
    }
}
