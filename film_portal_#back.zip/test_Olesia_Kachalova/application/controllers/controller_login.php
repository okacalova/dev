<?php
include_once($_SERVER['DOCUMENT_ROOT'] . "/application/models/model_login.php");

class Controller_Login extends Controller
{


	function __construct()
	{
		$this->model = new Model_Login();
		$this->view = new View();
	}


	function action_index()
	{

        
		if($this->model->check_login()){


		if (isset($_POST['submit'])) {
			if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
				header("Location: /");
				exit();
			}
		}
	}

		$this->view->generate('login_view.php', 'template_view.php');
	}
}
