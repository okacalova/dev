<?php
include_once($_SERVER['DOCUMENT_ROOT'] . "/application/models/model_main.php");
class Controller_Main extends Controller
{

	function __construct()
	{
		$this->model = new Model_Main();
		$this->view = new View();
	}
	function action_index()
	{	

		if(!isset($_SESSION['loggedin']))
		{
			header("Location: /login");
		}
		if(isset($_POST['logout'])){
				session_start();
				session_destroy();
		
				header("Location: /login");
			}

			//Get data
			$data = $this->model->get_data();

			//Get films
			$film = $this->model->get_films();

		$this->view->generate('main_view.php', 'template_view.php', ['data'=>$data, 'film'=>$film]);
	}
}
