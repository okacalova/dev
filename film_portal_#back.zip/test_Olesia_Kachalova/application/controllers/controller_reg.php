<?php
include_once($_SERVER['DOCUMENT_ROOT'] . "/application/models/model_reg.php");

class Controller_Reg extends Controller
{


	function __construct()
	{
		$this->model = new Model_Reg();
		$this->view = new View();
	}


	function action_index()
	{
        if(!isset($_SESSION['loggedin']))
		{
			header("Location: /login");
		}
		if(isset($_POST['logout'])){
				session_start();
				session_destroy();
		
				header("Location: /login");
			}


		$dataId = $this->model->findId();
        $data = $this->model->get_data();

		//Insert Reg
		$this->model->Insert_data();

        
		$this->view->generate('reg_view.php', 'template_view.php',['data'=>$data, 'dataId'=>$dataId]);
	}
}
