<?php 
require_once($_SERVER['DOCUMENT_ROOT']."/application/database/db.php");

class Model
{
	protected $Db = null;


	public function __construct(){
		$this->Db = new DB();
	}

	public function findId(){
		
	}

	public function get_data(){
		
	}

	public function get_films(){
		
	}

	public function Insert_data(){
		
	}

	public function delete_data(){

	}

	public function update_data(){
	}

	public function check_login()
	{
	}
}
?> 