<?php
define('DB_HOST', 'localhost:8889');
define('DB_USER', 'root');
define('DB_PASSWORD', 'root');
define('DB_DATABASE', 'test_olesia_kachalova');


class DB
{

    private $conn;
    public $db;
    public function __construct()
    {
        try {
            $this->conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
            // echo "Connection is good ";
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }
    }


    //Insert query
    public function Insert($query)
    {

        try {
            $result = $this->conn->query($query);
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }
        return $result;
    }

    // Select a row/s in a Database Table
    public function Select($query)
    {
        try {
            $result = $this->conn->query($query);
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }
        return $result;
    }

    // Update a row/s in a Database Table
    public function Update($query)
    {
        try {
            $result = $this->conn->query($query);
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }
        return $result;
    }

    // Remove a row/s in a Database Table
    public function Remove($query)
    {
        try {
            $result = $this->conn->query($query);
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }
        return $result;
    }
}
