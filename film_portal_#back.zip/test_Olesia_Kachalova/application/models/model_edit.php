<?php
session_start();

class Model_Edit extends Model
{

    //Session flash message
    function message($message)
    {
        $_SESSION['message'] = "$message";
    }

    //Validate post/get type
    function validate($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }


    public function update_data()
    {


        if (isset($_POST['saveId']) && isset($_POST['name'])) {

            $id = $this->validate($_POST['saveId']);
            $name = $this->validate($_POST['name']);

            $result = $this->Db->Update("UPDATE `director` SET `name` = '$name' WHERE  `directorId` = '$id'");

            return $result;
        }
    }

    //Delete data
    public function delete_data()
    {

        if (isset($_POST['delid'])) {
            $id = $this->validate($_POST['delid']);
            $result = $this->Db->Remove("DELETE FROM `director` WHERE `directorId` = '$id'");

            return $result;
        }
    }
}
