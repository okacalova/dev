<?php
session_start();

class Model_Film extends Model
{

    //Session flash message
    function message($message)
    {
        $_SESSION['message'] = "$message";
    }

    //Validate post/get type
    function validate($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }


    //Find data id
    public function findId()
    {
        if (isset($_POST['viewId'])) {
            $id = $_POST['viewId'];

            $result = $this->Db->Select("SELECT * FROM `movie` WHERE `movieId` = '$id'")->fetch_assoc();

            return $result;
        }
    }


    //Insert Фільма
    public function Insert_data()
    {
        if (isset($_POST['insertId']) && isset($_POST['insertName']) && isset($_POST['insertDescription']) && isset($_POST['insertRelease'])) {
        
            $directorId = $this->validate($_POST['insertId']);
            $filmName = $this->validate($_POST['insertName']);
            $filmDescription = $this->validate($_POST['insertDescription']);
            $releaseDate = $this->validate($_POST['insertRelease']);


            $result = $this->Db->Insert("INSERT INTO `movie`(`directorId`, `name`, `description`, `releaseDate`) VALUES ('$directorId','$filmName','$filmDescription','$releaseDate')");
        
            return $result;
        }
    }

    //Update data

    public function update_data()
    {


        if (isset($_POST['saveId']) && isset($_POST['filmName']) && isset($_POST['filmDescription'])) {
            $id = $this->validate($_POST['saveId']);
            $name = $this->validate($_POST['filmName']);
            $description = $this->validate($_POST['filmDescription']);

            $result = $this->Db->Update("UPDATE `movie` SET `name` = '$name', `description` = '$description' WHERE  `movieId` = '$id'");

            return $result;
        }
    }

    //Delete data 

    public function delete_data()
    {

        if (isset($_POST['delFilm'])) {
            $id = $this->validate($_POST['delFilm']);

            $result = $this->Db->Remove("DELETE FROM `movie` WHERE `movieId` = '$id'");

            return $result;
        }
    }
}
