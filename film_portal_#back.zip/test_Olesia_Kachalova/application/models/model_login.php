<?php
session_start();

class Model_Login extends Model
{

    //Session flash message
    function message($message)
    {
        $_SESSION['message'] = "$message";
    }

    //Validate post/get type
    function validate($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

//Get data 
    public function findId()
    {
        try {
            $result = $this->Db->Select('');
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }

        return $result;
    }

    //Check login
    public function check_login()
    {
        if (isset($_POST['login']) && isset($_POST['password'])) {
            $login = $this->validate($_POST['login']);
            $pass = $this->validate($_POST['password']);

            $result = $this->Db->Select("SELECT `id`, `password` FROM `users` WHERE `name` = '$login' AND `password` = '$pass'")->fetch_assoc();

            if ($result) {

                $_SESSION['loggedin'] = true;
                $_SESSION['name'] = $login;
            } else {
                $this->message("<div class='alert alert-danger' role='alert'>Логін або пароль введено не вірно </div>");
            }
            return $result;
        }
    }
}
