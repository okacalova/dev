<?php
session_start();

class Model_Main extends Model
{

    //Session flash message
    function message($message)
    {
        $_SESSION['message'] = "$message";
    }

    //Validate post/get type
    function validate($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

//Get data 

    public function get_data(){
        try {
            $result = $this->Db->Select("SELECT directorId, name FROM `director`");
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }

        return $result;
    }

    //Get films

    public function get_films(){
        try {
            $result = $this->Db->Select("SELECT m.movieId, m.name AS filmName, m.description, m.releaseDate, d.name FROM `movie` AS `m` JOIN `director` AS `d` ON m.directorId = d.directorId ")->fetch_all(MYSQLI_ASSOC);
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }

        return $result;
    }


}
