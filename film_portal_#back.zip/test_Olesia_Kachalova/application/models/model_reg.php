<?php
session_start();

class Model_Reg extends Model
{

    //Session flash message
    function message($message)
    {
        $_SESSION['message'] = "$message";
    }

    //Validate post/get type
    function validate($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }


    //Get data 

    public function get_data()
    {
        try {
            $result = $this->Db->Select("SELECT * FROM `director`")->fetch_all();
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }

        return $result;
    }

    //Find data id
    public function findId()
    {

        $id = $this->validate($_POST['directorId']);

        $result = $this->Db->Select("SELECT * FROM `director` WHERE directorId = '$id'")->fetch_assoc();


        return $result;
    }


    //Insert Режисер

    public function Insert_data()
    {
        if (isset($_POST['insertId']) && isset($_POST['insertName'])) {
            $directorId = $this->validate($_POST['insertId']);
            $regName = $this->validate($_POST['insertName']);

            $result = $this->Db->Insert("INSERT INTO `director`(`directorId`, `name`) VALUES ('$directorId','$regName')");

            return $result;
        }
    }
}
