<nav class="navbar navbar-expand-lg navbar-light bg-light">

		<form action="/" method="POST">
			<input class="btn btn-outline-success my-2 my-sm-0" type="submit" name="films" value="Фільми">
		</form>

        <button type="button" class="btn btn-success insert_film" data-toggle="modal">Додати Фільм</button>
	</nav>



<div class="container">
    <table>
        <ul>
            <label for="">ID:</label>
            <li>
            <p class="editId"><?php echo $data['movieId'] ?></p>
            </li>
            <label for="">Фільм:</label>
            <li>

                <p class="film_Name"><?php echo $data['name'] ?></p>

            </li>
            <label for="">Опис:</label>
            <li>
                <textarea disabled class="filmDescription"><?php echo $data['description'] ?></textarea>
            </li>
            <label for="">Дата виходу на екрани:</label>
            <li>

                <label><?php echo $data['releaseDate'] ?></label>
            </li>
            <hr>
            <div class="btn-group">
            
            <button type="button" class="btn btn-sm btn-outline-success editFilm" data-toggle="modal">Edit</button>
            <button type="button" class="btn btn-sm btn-outline-danger deleteFilm">Delete</button>
            
            </div>
        </ul>
        <!-- btn edit -->
       

    </table>
</div>



<!-- Model popup Edit-->

<div class="modal" id="modal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Редагування</h5>
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="id">
                <input type="text" id="filmName">
                <input type="text" id="filmDescription">
            </div>
            <div class="modal-footer">
                <button type="button" id="saveFilm" class="btn btn-primary">Зберегти</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>


<!-- Model popup Add -->

<div class="modal" id="modal_add" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Редагування</h5>
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <ul>
                <input type="hidden" id="id">
                <label for="">DirectorId</label>
                <li><input type="text" id="insertId"></li>
                <label for="">Movie name</label>
                <li><input type="text" id="insertName"></li>
                <label for="">Description</label>
                <li><input type="text" id="insertDescription"></li>
                <label for="">Release Date</label>
                <li><input type="date" id="insertRelease"></li>
                </ul>
            </div>
            <div class="modal-footer">
                <button type="button" id="insertFilm" class="btn btn-primary">Зберегти</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
