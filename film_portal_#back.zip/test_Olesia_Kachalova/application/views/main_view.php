<!-- nav bar -->
<?php
if (isset($_SESSION['loggedin'])) {
?>
	<nav class="navbar navbar-expand-lg navbar-light bg-light">

		<form action="" method="POST">
			<input class="btn btn-outline-secondary my-2 my-sm-0" type="submit" name="films" value="Фільми">
		</form>
		<div class="collapse navbar-collapse" id="navbarSupportedContent">
			<div class="dropdown">
				<button class="btn btn-outline-secondary my-2 my-sm-0 dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
					Режисери
				</button>

				<ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
					<?php
					foreach ($data as $row) {   ?>
						<form action="/reg" method="POST">
							<li><input type="hidden" name="directorId" value="<?php echo $row['directorId'] ?>"></li>
							<li><input class="dropdown-item" type=submit name="directorName" value="<?php echo $row['name'] ?>"></li>
						</form>
					<?php } ?>
					<li>
						<input type="button" class="btn btn btn-outline-secondary insert_reg" data-toggle="modal" value="Додати Режисера" />
					</li>
				</ul>

			</div>

		</div>
		<form action="" class="form-inline my-2 my-lg-0" method="POST">
			<button id="logout" class="btn btn-outline-secondary my-2 my-sm-0" type="submit" name="logout">Вихід</button>
		</form>
	</nav>

	<!-- end nav bar -->

	<main role="main">

		<section class="jumbotron text-center section">
			<div class="container">
				<h1 class="jumbotron-heading">Кінофобія 2023</h1>
				<p class="lead text-muted">Серіали, Фильмі, Телепередачи та багато іншого цікавого контенту</p>
			</div>
		</section>

		<div class="album py-5 bg-light">
			<div class="container">

				<div class="row">
					<?php foreach ($film as $row) { ?>

						<div class="col-md-4">
							<div class="card mb-4 box-shadow">
								<img class="card-img-top" data-src="holder.js/100px225?theme=thumb&bg=55595c&fg=eceeef&text=Thumbnail" alt="Card image cap">
								<div class="card-body">
									<h4>
										<p class="card-text filmName"><?php echo $row['filmName'] ?></p>
									</h4>
									<label for="">Опис:</label>
									<p class="card-text filmDescription"><?php echo $row['description'] ?></p>
									<label for="">Режисер:</label>
									<p class="card-text"><?php echo $row['name'] ?></p>
									<div class="d-flex justify-content-between align-items-center">
										<div class="btn-group">
											<!-- form view -->
											<form action="/film" method="POST">
												<input type="hidden" id="viewId" name="viewId" value="<?php echo $row['movieId'] ?>">
												<input type="submit" class="btn btn-sm btn-outline-success" id="view" value="View" />
											</form>

										</div>
										<small class="text-muted"><?php echo date("d.m.Y", strtotime($row['releaseDate'])) ?></small>
									</div>
								</div>
							</div>
						</div>

					<?php } ?>
				</div>
			</div>
		</div>



		<!-- Model popup Add -->

		<div class="modal" id="modal_add_reg" tabindex="-1" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title">Редагування</h5>
						<button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<ul>
							<input type="hidden" id="id">
							<label for="">DirectorId</label>
							<li><input type="text" id="insertId"></li>
							<label for="">Name</label>
							<li><input type="text" id="insertName"></li>
						</ul>
					</div>
					<div class="modal-footer">
						<button type="button" id="insertReg" class="btn btn-primary">Зберегти</button>
						<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>

	<?php } ?>