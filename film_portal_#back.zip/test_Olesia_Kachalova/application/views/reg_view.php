<nav class="navbar navbar-expand-lg navbar-light bg-light">


    <a href="/" class="btn btn-outline-secondary my-2 my-sm-0">Фільми</a>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <div class="dropdown">
            <button class="btn btn-outline-secondary my-2 my-sm-0 dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                Режисери
            </button>

            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                <?php foreach ($data as $row) { ?>
                    <form action="/reg" method="POST">
                        <li><input type="hidden" name="directorId" value="<?php echo $row['0'] ?>"></li>
                        <li><input class="dropdown-item" type=submit name="directorName" value="<?php echo $row['1'] ?>"></li>
                    </form>
                <?php } ?>
            </ul>

        </div>

        <form action="" class="form-inline my-2 my-lg-0" method="POST">
            <button id="logout" class="btn btn-outline-secondary my-2 my-sm-0" type="submit" name="logout">Вихід</button>
        </form>

    </div>
</nav>

<!-- end nav bar -->
<div class="container">
    <div class="row">
        <div class="col-12">
            <table class="table table-bordered">
                
                <thead>
                    <tr>
                        <th scope="col">Id</th>
                        <th scope="col">Name</th>
                        <th scope="col">Actions</th>

                    </tr>
                </thead>
                <tbody>
                        <tr data-target="<?php echo $dataId['directorId'] ?>">

                            <th scope="row" class="id"><?php echo $dataId['directorId'] ?></th>
                            <td class="name"><?php echo $dataId['name'] ?></td>
                            <td>
                                <input type="hidden" id="_directorId" value="<?php echo $dataId['directorId'] ?>">
                                <button type="button" class="btn btn-success btn-modal" data-toggle="modal"><i class="fas fa-edit"></i></button>
                                <button type="button" class="btn btn-danger delete" ><i class="far fa-trash-alt"></i></button>
                            </td>

                        </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>


<!-- Model popup -->

<div class="modal" id="Modal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modal title</h5>
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <input type="hidden" id="id">
                <input type="text" id="name">
            </div>
            <div class="modal-footer">
                <button type="button" id="save" class="btn btn-primary">Save</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>