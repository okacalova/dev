$(document).ready(() => {


    

    $(".btn-modal").click(function () { 

        var id = $(".id").text();
        var name = $(".name").text();

        $('#id').val(id); 
        $('#name').val(name); 
        $("#Modal").modal('show');

       
            
        });

        $("#save").click(function () { 
            

            var saveId = $("#id").val();
            var name = $("#name").val();
        
            $.ajax({
                type: "POST",
                url: "/edit",
                caches:false,
                data: 
                {
                    saveId,
                    name,
                },
                success: function () {
                    
                    $("#Modal").modal('hide');
            }});

            location.reload();
    });

    $(".delete").click(function(){ 
        
        var delid = $("#_directorId").val();

        $.ajax({
            type: "POST",
            url: "/edit",
            caches:false,
            data: 
            {
                delid,
            },
            success: function (data) 
            {
                if(data)
                {
                location.href = "/main";
                }
            }
    });
});

    //Update film

    $(".editFilm").click(function () { 

        var editId = $(".editId").text();
        var filmName = $(".film_Name").text();
        var filmDescription = $(".filmDescription").text();
 
 
        $('#id').val(editId); 
        $('#filmName').val(filmName); 
        $('#filmDescription').val(filmDescription); 
        $("#modal").modal('show');

       
            
        });

        $("#saveFilm").click(function () { 
            

            var saveId = $("#id").val();
            var filmName = $("#filmName").val();
            var filmDescription = $("#filmDescription").val();
        
            $.ajax({
                type: "POST",
                url: "/film",
                caches:false,
                data: 
                {
                    saveId,
                    filmName,
                    filmDescription,
                },
                success: function () {
                    
                    $("#modal").modal('hide');
            }});

            location.reload();
    });

    // Delete film

    $(".deleteFilm").click(function () { 
        
        var delFilm = $(".editId").text();

        $.ajax({
            type: "POST",
            url: "/film",
            caches:false,
            data: 
            {
                delFilm,
            },
            success: function (data) {
                if(data)
                {
                location.href = "/main";
                }
        }});

    });

        //Insert film

        $(".insert_film").click(function () { 
            $("#modal_add").modal('show');

            $("#insertFilm").click(function () { 

            
            var insertId = $("#insertId").val();
            var insertName = $("#insertName").val();
            var insertDescription = $("#insertDescription").val();
            var insertRelease = $("#insertRelease").val();
           


            $.ajax({
                type: "POST",
                url: "/film",
                caches:false,
                data: 
                {
                    insertId,
                    insertName,
                    insertDescription,
                    insertRelease,
                },
                success: function () {
                    
                    
                $("#modal_add").modal('hide');
                    
            }});

           location.href = "/main";
     });
    });

    
//insert Reg

//Insert data

$(".insert_reg").click(function () { 
    $("#modal_add_reg").modal('show');

    $("#insertReg").click(function () { 

    
    var insertId = $("#insertId").val();
    var insertName = $("#insertName").val();
    
   


    $.ajax({
        type: "POST",
        url: "/reg",
        caches:false,
        data: 
        {
            insertId,
            insertName,
        },
        success: function () {
            
            
        $("#modal_add").modal('hide');
            
    }});
    
    location.reload();
});
});

});
